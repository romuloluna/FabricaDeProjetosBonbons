
import React, { useState } from 'react';
import { MOCK_DOCUMENTS } from '../../constants';
import { Document } from '../../types';

const SecurityModal: React.FC<{ onVerify: () => void; onCancel: () => void }> = ({ onVerify, onCancel }) => {
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleVerify = () => {
        if (password === 'password123') { // Fake password
            onVerify();
        } else {
            setError('Incorrect password. Please try again.');
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-8 w-full max-w-sm">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Security Check</h2>
                <p className="text-gray-600 dark:text-gray-400 mt-2">Please enter your password to view this secure document.</p>
                <input 
                    type="password"
                    value={password}
                    onChange={(e) => { setPassword(e.target.value); setError(''); }}
                    className="w-full mt-4 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-indigo-500 text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-700"
                    placeholder="Enter password..."
                />
                {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
                <div className="flex justify-end space-x-4 mt-6">
                    <button onClick={onCancel} className="px-4 py-2 rounded-md text-gray-700 dark:text-gray-300 bg-gray-200 dark:bg-gray-600 hover:bg-gray-300 dark:hover:bg-gray-500">Cancel</button>
                    <button onClick={handleVerify} className="px-4 py-2 rounded-md text-white bg-indigo-600 hover:bg-indigo-700">Verify</button>
                </div>
            </div>
        </div>
    );
};

const SignatureModal: React.FC<{ doc: Document; onSign: (docId: number) => void; onClose: () => void }> = ({ doc, onSign, onClose }) => {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-8 w-full max-w-2xl">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{doc.title}</h2>
                <div className="my-4 p-4 h-64 overflow-y-auto border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300">
                    <h3 className="font-bold">Lorem Ipsum Dolor Sit Amet</h3>
                    <p>Consectetur adipiscing elit. Sed non risus. Suspendisse lectus tortor, dignissim sit amet, adipiscing nec, ultricies sed, dolor. Cras elementum ultrices diam. Maecenas ligula massa, varius a, semper congue, euismod non, mi. Proin porttitor, orci nec nonummy molestie, enim est eleifend mi, non fermentum diam nisl sit amet erat. Duis semper. Duis arcu massa, scelerisque vitae, consequat in, pretium a, enim. Pellentesque congue. Ut in risus volutpat libero pharetra tempor.</p>
                </div>
                <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Signature</label>
                    <div className="mt-1 p-4 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-md h-32 flex items-center justify-center">
                        <p className="text-gray-400 italic">Signature area - Please click "Sign Document" to apply your digital signature.</p>
                    </div>
                </div>
                 <div className="flex justify-end space-x-4 mt-6">
                    <button onClick={onClose} className="px-4 py-2 rounded-md text-gray-700 dark:text-gray-300 bg-gray-200 dark:bg-gray-600 hover:bg-gray-300 dark:hover:bg-gray-500">Close</p>
                    <button onClick={() => onSign(doc.id)} className="px-4 py-2 rounded-md text-white bg-green-600 hover:bg-green-700">Sign Document</button>
                </div>
            </div>
        </div>
    );
};

const DocumentsPage: React.FC = () => {
    const [documents, setDocuments] = useState<Document[]>(MOCK_DOCUMENTS);
    const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);
    const [isSecurityModalOpen, setIsSecurityModalOpen] = useState(false);
    const [isSignatureModalOpen, setIsSignatureModalOpen] = useState(false);

    const handleSignClick = (doc: Document) => {
        setSelectedDoc(doc);
        setIsSecurityModalOpen(true);
    };

    const handleSecuritySuccess = () => {
        setIsSecurityModalOpen(false);
        setIsSignatureModalOpen(true);
    };

    const handleSignDocument = (docId: number) => {
        setDocuments(docs => docs.map(d => d.id === docId ? { ...d, isSigned: true } : d));
        setIsSignatureModalOpen(false);
        setSelectedDoc(null);
    };

    return (
        <div>
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-6">Document Storage & Signature</h1>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                 <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="text-xs text-gray-500 dark:text-gray-400 uppercase bg-gray-50 dark:bg-gray-700">
                            <tr>
                                <th className="py-3 px-4">Document Title</th>
                                <th className="py-3 px-4">Type</th>
                                <th className="py-3 px-4">Date Added</th>
                                <th className="py-3 px-4 text-center">Status</th>
                                <th className="py-3 px-4 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {documents.map(doc => (
                                <tr key={doc.id} className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                                    <td className="py-3 px-4 text-gray-800 dark:text-white font-medium">{doc.title}</td>
                                    <td className="py-3 px-4 text-gray-600 dark:text-gray-300">{doc.type}</td>
                                    <td className="py-3 px-4 text-gray-600 dark:text-gray-300">{doc.dateAdded}</td>
                                    <td className="py-3 px-4 text-center">
                                        {doc.isSigned ? (
                                            <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">Signed</span>
                                        ) : (
                                            <span className="px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300">Pending</span>
                                        )}
                                    </td>
                                    <td className="py-3 px-4 text-center">
                                        <button 
                                            onClick={() => !doc.isSigned && handleSignClick(doc)}
                                            disabled={doc.isSigned}
                                            className="px-4 py-2 text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                                        >
                                            {doc.isSigned ? 'View Signed' : 'Sign'}
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            {isSecurityModalOpen && selectedDoc && <SecurityModal onVerify={handleSecuritySuccess} onCancel={() => setIsSecurityModalOpen(false)} />}
            {isSignatureModalOpen && selectedDoc && <SignatureModal doc={selectedDoc} onSign={handleSignDocument} onClose={() => setIsSignatureModalOpen(false)} />}
        </div>
    );
};

export default DocumentsPage;
