
import React, { useState } from 'react';

const VideoPlaceholder: React.FC<{ name: string; isMuted?: boolean }> = ({ name, isMuted = false }) => (
    <div className="relative aspect-video bg-gray-700 rounded-lg flex items-center justify-center">
        <div className="absolute top-2 left-2 bg-black bg-opacity-50 text-white text-sm px-2 py-1 rounded">
            {name}
        </div>
        <svg className="w-16 h-16 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
        {isMuted && (
             <div className="absolute bottom-2 right-2 bg-red-500 p-1.5 rounded-full">
                <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path></svg>
            </div>
        )}
    </div>
);

const MeetingsPage: React.FC = () => {
    const [isMuted, setIsMuted] = useState(false);
    const [isCameraOff, setIsCameraOff] = useState(false);

    return (
        <div>
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">Virtual Meeting Room</h1>
            <p className="text-gray-600 dark:text-gray-400 mb-6">Interview with Elena Rodriguez - Senior Frontend Engineer</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className={`relative aspect-video rounded-lg overflow-hidden border-2 ${isCameraOff ? 'bg-gray-900' : 'bg-black'} border-indigo-500`}>
                    {isCameraOff ? (
                         <div className="flex flex-col items-center justify-center h-full">
                            <img className="h-24 w-24 rounded-full object-cover mb-4" src="https://picsum.photos/id/1025/200/200" alt="Your avatar" />
                            <p className="text-white font-semibold">Jane Doe (You)</p>
                            <p className="text-gray-400 text-sm">Camera is off</p>
                        </div>
                    ) : (
                         <img src="https://picsum.photos/seed/meeting1/1280/720" className="w-full h-full object-cover" alt="Your video feed" />
                    )}
                     <div className="absolute top-2 left-2 bg-black bg-opacity-50 text-white text-sm px-2 py-1 rounded">
                        Jane Doe (You)
                    </div>
                </div>
                
                <VideoPlaceholder name="Elena Rodriguez" isMuted />
            </div>

            <div className="mt-6 bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 flex justify-center items-center space-x-4">
                <button
                    onClick={() => setIsMuted(!isMuted)}
                    className={`p-3 rounded-full transition-colors ${isMuted ? 'bg-red-500 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white'}`}
                    aria-label={isMuted ? "Unmute" : "Mute"}
                >
                    {isMuted ? (
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path></svg>
                    ) : (
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"></path></svg>
                    )}
                </button>
                <button
                    onClick={() => setIsCameraOff(!isCameraOff)}
                    className={`p-3 rounded-full transition-colors ${isCameraOff ? 'bg-red-500 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white'}`}
                    aria-label={isCameraOff ? "Turn camera on" : "Turn camera off"}
                >
                     {isCameraOff ? (
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
                     ) : (
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                     )}
                </button>
                <button
                    className="px-6 py-3 rounded-full bg-red-600 text-white font-semibold hover:bg-red-700 transition-colors"
                >
                    End Call
                </button>
            </div>
        </div>
    );
};

export default MeetingsPage;
