
import React, { useState, useRef, useEffect } from 'react';
import { sendMessageToGeminiStream } from '../../services/geminiService';
import { ChatMessage, MessageAuthor } from '../../types';
import { SendIcon, ProfileIcon } from '../Icons';

const ChatPage: React.FC = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([
        { author: MessageAuthor.Bot, text: 'Hello! How can I assist you with your HR needs today?' }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleSend = async () => {
        if (input.trim() === '' || isLoading) return;

        const userMessage: ChatMessage = { author: MessageAuthor.User, text: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            const stream = await sendMessageToGeminiStream(input);
            
            let botMessage: ChatMessage = { author: MessageAuthor.Bot, text: '' };
            setMessages(prev => [...prev, botMessage]);

            for await (const chunk of stream) {
                botMessage.text += chunk.text;
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1] = { ...botMessage };
                    return newMessages;
                });
            }
        } catch (error) {
            const errorMessage: ChatMessage = { 
                author: MessageAuthor.Bot, 
                text: 'Sorry, I encountered an error. Please try again later.' 
            };
            setMessages(prev => [...prev, errorMessage]);
            console.error(error);
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <div className="flex flex-col h-[calc(100vh-144px)] max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-6">Chat Assistant</h1>
            <div className="flex-1 overflow-y-auto bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 space-y-4">
                {messages.map((msg, index) => (
                    <div key={index} className={`flex items-start gap-4 ${msg.author === MessageAuthor.User ? 'justify-end' : ''}`}>
                        {msg.author === MessageAuthor.Bot && (
                            <div className="flex-shrink-0 h-10 w-10 rounded-full bg-indigo-500 flex items-center justify-center text-white">
                                <ProfileIcon className="h-6 w-6" />
                            </div>
                        )}
                        <div className={`max-w-lg p-4 rounded-xl ${msg.author === MessageAuthor.User ? 'bg-indigo-500 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200'}`}>
                            <p className="text-sm" style={{ whiteSpace: 'pre-wrap' }}>{msg.text}</p>
                        </div>
                         {msg.author === MessageAuthor.User && (
                            <img className="flex-shrink-0 h-10 w-10 rounded-full object-cover" src="https://picsum.photos/id/1025/200/200" alt="User avatar" />
                        )}
                    </div>
                ))}
                {isLoading && messages[messages.length-1].author === MessageAuthor.User && (
                     <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-indigo-500 flex items-center justify-center text-white">
                            <ProfileIcon className="h-6 w-6" />
                        </div>
                        <div className="max-w-lg p-4 rounded-xl bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
                           <div className="flex items-center space-x-1">
                                <span className="w-2 h-2 bg-indigo-400 rounded-full animate-pulse [animation-delay:-0.3s]"></span>
                                <span className="w-2 h-2 bg-indigo-400 rounded-full animate-pulse [animation-delay:-0.15s]"></span>
                                <span className="w-2 h-2 bg-indigo-400 rounded-full animate-pulse"></span>
                           </div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>
            <div className="mt-6">
                <div className="flex items-center bg-white dark:bg-gray-800 rounded-lg shadow-md p-2">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="Ask an HR-related question..."
                        className="flex-1 bg-transparent border-none focus:ring-0 text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
                        disabled={isLoading}
                    />
                    <button
                        onClick={handleSend}
                        disabled={isLoading || input.trim() === ''}
                        className="p-2 rounded-full bg-indigo-600 text-white hover:bg-indigo-700 disabled:bg-indigo-300 disabled:cursor-not-allowed transition-colors"
                    >
                        <SendIcon className="h-5 w-5" />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ChatPage;
