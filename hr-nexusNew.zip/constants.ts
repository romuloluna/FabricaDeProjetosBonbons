import { Candidate, Document, CandidateStatus, Meeting } from './types';

export const MOCK_CANDIDATES: Candidate[] = [
    { id: 1, name: 'Elena Rodriguez', avatarUrl: 'https://picsum.photos/id/1027/200/200', position: 'Senior Frontend Engineer', status: CandidateStatus.Interviewing, appliedDate: '2024-07-15', email: 'elena.r@example.com' },
    { id: 2, name: 'Benjamin Carter', avatarUrl: 'https://picsum.photos/id/1005/200/200', position: 'UX/UI Designer', status: CandidateStatus.Offered, appliedDate: '2024-07-12', email: 'ben.c@example.com' },
    { id: 3, name: 'Aisha Khan', avatarUrl: 'https://picsum.photos/id/1011/200/200', position: 'Product Manager', status: CandidateStatus.Applied, appliedDate: '2024-07-20', email: 'aisha.k@example.com' },
    { id: 4, name: 'David Lee', avatarUrl: 'https://picsum.photos/id/1012/200/200', position: 'Backend Developer', status: CandidateStatus.Hired, appliedDate: '2024-06-28', email: 'david.l@example.com' },
    { id: 5, name: 'Sophia Chen', avatarUrl: 'https://picsum.photos/id/1013/200/200', position: 'Data Scientist', status: CandidateStatus.Rejected, appliedDate: '2024-07-05', email: 'sophia.c@example.com' },
    { id: 6, name: 'Michael Johnson', avatarUrl: 'https://picsum.photos/id/1014/200/200', position: 'DevOps Engineer', status: CandidateStatus.Interviewing, appliedDate: '2024-07-18', email: 'michael.j@example.com' },
];

export const MOCK_DOCUMENTS: Document[] = [
    { id: 1, title: 'Offer Letter - Benjamin Carter', type: 'Offer Letter', dateAdded: '2024-07-18', isSigned: false },
    { id: 2, title: 'Employment Contract - David Lee', type: 'Contract', dateAdded: '2024-07-01', isSigned: true, signedDate: '2024-07-02' },
    { id: 3, title: 'NDA - Elena Rodriguez', type: 'NDA', dateAdded: '2024-07-16', isSigned: true, signedDate: '2024-07-17' },
    { id: 4, title: 'Contract - Freelance Designer', type: 'Contract', dateAdded: '2024-07-21', isSigned: false },
];

export const MOCK_MEETINGS: Meeting[] = [
    { 
        id: 'interview-elena-rodriguez', 
        title: 'Interview with Elena Rodriguez', 
        participants: ['Jane Doe', 'Elena Rodriguez'], 
        dateTime: '2024-08-15T10:00:00Z' 
    },
    { 
        id: 'weekly-sync-design', 
        title: 'Weekly Sync - Design Team', 
        participants: ['Jane Doe', 'Benjamin Carter', 'Aisha Khan'], 
        dateTime: '2024-08-16T14:30:00Z' 
    },
    { 
        id: 'project-kickoff-ats', 
        title: 'Project Kickoff: New ATS', 
        participants: ['Jane Doe', 'David Lee', 'Michael Johnson'], 
        dateTime: '2024-08-19T11:00:00Z' 
    },
];