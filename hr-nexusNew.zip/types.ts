export enum CandidateStatus {
    Applied = 'Applied',
    Interviewing = 'Interviewing',
    Offered = 'Offered',
    Hired = 'Hired',
    Rejected = 'Rejected',
}

export interface Candidate {
    id: number;
    name: string;
    avatarUrl: string;
    position: string;
    status: CandidateStatus;
    appliedDate: string;
    email: string;
}

export interface Document {
    id: number;
    title: string;
    type: 'Offer Letter' | 'Contract' | 'NDA';
    dateAdded: string;
    isSigned: boolean;
    signedDate?: string;
    signerName?: string;
    signerPosition?: string;
}

export enum MessageAuthor {
    User = 'user',
    Bot = 'bot',
}

export interface ChatMessage {
    author: MessageAuthor;
    text: string;
}

export interface Meeting {
    id: string;
    title: string;
    participants: string[];
    dateTime: string;
}