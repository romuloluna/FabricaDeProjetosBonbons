
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import DocumentationInput from './components/DocumentationInput';
import TestPlanDisplay from './components/TestPlanDisplay';
import { generateTestPlan } from './services/geminiService';

const App: React.FC = () => {
  const [documentation, setDocumentation] = useState<string>('');
  const [testPlan, setTestPlan] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateTestPlan = useCallback(async () => {
    if (!documentation.trim()) {
      setError('Documentation cannot be empty.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setTestPlan('');

    try {
      const result = await generateTestPlan(documentation);
      setTestPlan(result);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(`Failed to generate test plan: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  }, [documentation]);

  return (
    <div className="min-h-screen bg-brand-background text-brand-text font-sans flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-4xl mx-auto">
        <Header />
        <main className="mt-8 space-y-8">
          <DocumentationInput
            documentation={documentation}
            setDocumentation={setDocumentation}
            onGenerate={handleGenerateTestPlan}
            isLoading={isLoading}
          />
          <TestPlanDisplay
            testPlan={testPlan}
            isLoading={isLoading}
            error={error}
          />
        </main>
      </div>
       <footer className="w-full max-w-4xl mx-auto text-center py-6 mt-8 text-brand-text-muted text-sm">
        <p>Powered by Google Gemini. For informational purposes only.</p>
      </footer>
    </div>
  );
};

export default App;
