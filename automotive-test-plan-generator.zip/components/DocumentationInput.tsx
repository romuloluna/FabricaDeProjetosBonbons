
import React from 'react';
import { SparkleIcon } from './icons';

interface DocumentationInputProps {
  documentation: string;
  setDocumentation: (value: string) => void;
  onGenerate: () => void;
  isLoading: boolean;
}

const DocumentationInput: React.FC<DocumentationInputProps> = ({
  documentation,
  setDocumentation,
  onGenerate,
  isLoading,
}) => {
  return (
    <div className="bg-brand-surface p-6 rounded-lg shadow-lg">
      <label htmlFor="documentation-input" className="block text-sm font-medium text-brand-text-muted mb-2">
        Paste Documentation
      </label>
      <textarea
        id="documentation-input"
        value={documentation}
        onChange={(e) => setDocumentation(e.target.value)}
        placeholder="Paste your CSV or function documentation here..."
        className="w-full h-64 p-4 bg-brand-background border border-slate-600 rounded-md focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition duration-150 ease-in-out resize-y"
        disabled={isLoading}
      />
      <div className="mt-4 flex justify-end">
        <button
          onClick={onGenerate}
          disabled={isLoading || !documentation.trim()}
          className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-brand-primary hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-brand-surface focus:ring-brand-primary disabled:bg-slate-500 disabled:cursor-not-allowed transition-colors duration-200"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating...
            </>
          ) : (
             <>
              <SparkleIcon className="h-5 w-5 mr-2" />
              Generate Test Plan
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default DocumentationInput;
