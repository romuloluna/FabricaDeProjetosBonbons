
import React from 'react';
import Loader from './Loader';
import ErrorMessage from './ErrorMessage';
import MarkdownTableRenderer from './MarkdownTableRenderer';

interface TestPlanDisplayProps {
  testPlan: string;
  isLoading: boolean;
  error: string | null;
}

const TestPlanDisplay: React.FC<TestPlanDisplayProps> = ({ testPlan, isLoading, error }) => {
  const renderContent = () => {
    if (isLoading) {
      return <Loader />;
    }
    if (error) {
      return <ErrorMessage message={error} />;
    }
    if (testPlan) {
      return <MarkdownTableRenderer markdownContent={testPlan} />;
    }
    return (
      <div className="text-center py-16 text-brand-text-muted">
        <h3 className="text-lg font-medium">Your Generated Test Plan Will Appear Here</h3>
        <p className="mt-2 text-sm">Enter your documentation above and click "Generate Test Plan" to begin.</p>
      </div>
    );
  };

  return (
    <div className="bg-brand-surface p-4 sm:p-6 rounded-lg shadow-lg min-h-[20rem] flex flex-col justify-center">
      {renderContent()}
    </div>
  );
};

export default TestPlanDisplay;
