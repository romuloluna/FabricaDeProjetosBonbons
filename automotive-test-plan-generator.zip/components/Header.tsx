
import React from 'react';
import { DocumentIcon } from './icons';

const Header: React.FC = () => {
  return (
    <header className="text-center">
      <div className="flex justify-center items-center gap-4">
        <DocumentIcon className="h-10 w-10 text-brand-accent" />
        <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
          Automotive Test Plan Generator
        </h1>
      </div>
      <p className="mt-4 text-lg text-brand-text-muted max-w-2xl mx-auto">
        Paste your CSV or text documentation below, and our AI assistant will generate a comprehensive validation test plan in seconds.
      </p>
    </header>
  );
};

export default Header;
