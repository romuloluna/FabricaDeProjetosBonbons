
import React, { useMemo } from 'react';

interface MarkdownTableRendererProps {
  markdownContent: string;
}

const MarkdownTableRenderer: React.FC<MarkdownTableRendererProps> = ({ markdownContent }) => {
  const { headers, rows } = useMemo(() => {
    const lines = markdownContent.trim().split('\n');
    if (lines.length < 2) return { headers: [], rows: [] };

    const cleanCell = (cell: string) => cell.trim();

    const headerLine = lines[0];
    const newHeaders = headerLine.split('|').map(cleanCell).filter(Boolean);

    const newRows = lines.slice(2) // Skip header and separator line
      .map(line => line.split('|').map(cleanCell).filter(Boolean))
      .filter(row => row.length > 0 && row.some(cell => cell.length > 0));
      
    return { headers: newHeaders, rows: newRows };
  }, [markdownContent]);

  if (!headers.length || !rows.length) {
    return (
      <div className="bg-brand-background p-4 rounded-md text-brand-text-muted">
        <p className="font-semibold text-white">Could not render table.</p>
        <p className="text-sm mt-2">The AI response was not a valid markdown table. Displaying raw output:</p>
        <pre className="mt-4 whitespace-pre-wrap text-sm text-brand-text break-words">
          <code>{markdownContent}</code>
        </pre>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-slate-600 border border-slate-700">
        <thead className="bg-slate-700/50">
          <tr>
            {headers.map((header, index) => (
              <th key={index} scope="col" className="px-6 py-3 text-left text-xs font-medium text-brand-text-muted uppercase tracking-wider">
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="bg-brand-surface divide-y divide-slate-700">
          {rows.map((row, rowIndex) => (
            <tr key={rowIndex} className="hover:bg-slate-700/30 transition-colors duration-150">
              {row.map((cell, cellIndex) => (
                <td key={cellIndex} className="px-6 py-4 whitespace-pre-wrap text-sm text-brand-text align-top">
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MarkdownTableRenderer;
